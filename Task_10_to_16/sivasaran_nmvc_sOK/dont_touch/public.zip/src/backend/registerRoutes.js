const express = require('express');
const router = express.Router();
const { Pool } = require('pg');
const multer = require('multer');
const path = require('path');

// Database connection configuration
const pool = new Pool({
    user: 'Sivasaran',
    host: 'localhost',
    database: 'Sivasaran',
    password: 'password',
    port: 5432,
});

// Set up storage for multer
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const destinationPath = path.join(__dirname, '../uploads');
        console.log('File upload destination:', destinationPath); // Debug: Log destination path
        cb(null, destinationPath); // Corrects path to uploads folder at root
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const filename = file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname);
        console.log('Generated file name:', filename); // Debug: Log file name
        cb(null, filename); // Add unique suffix to filename
    }
});

const upload = multer({ storage: storage, limits: { fileSize: 5 * 1024 * 1024 } }); // Limit file size to 5MB
router.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// Insert a new user along with file upload
router.post('/', upload.single('profile_picture'), async (req, res) => {
    console.log("Received Data:", req.body); // Debug incoming data
    console.log("File Info:", req.file); // Debug uploaded file info

    const { name, organization, email, password, num_users, mobile, country_name, state_name, expiry_date } = req.body;
    const filePath = req.file ? `/uploads/${req.file.filename}` : null; // If a file is uploaded, store its path
    console.log('File path to be saved:', filePath); // Debug: Log file path

    try {
        console.log('Preparing to insert data into database'); // Debug: Log before SQL query
        // SQL Query to insert data
        const query = `
            INSERT INTO register
            (name, organization, email, password, num_users, mobile, country_name, state_name, expiry_date, file_path) 
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            RETURNING *;
        `;

        const result = await pool.query(query, [name, organization, email, password, num_users, mobile, country_name, state_name, expiry_date, filePath]);
        console.log('Database insertion result:', result.rows[0]); // Debug: Log result of insertion

        // Respond with the newly created record
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error('Error inserting data:', err); // Log detailed error
        res.status(500).json({ error: 'Failed to add user', details: err.message });
    }
});

// Fetch users
router.get('/', async (req, res) => {
    try {
        console.log('Fetching users from the database'); // Debug: Log before fetching users
        const users = await pool.query('SELECT * FROM register');
        console.log('Fetched users:', users.rows); // Debug: Log fetched users
        res.json(users.rows);
    } catch (err) {
        console.error('Error fetching users:', err); // Log error
        res.status(500).json({ error: 'Failed to fetch users' });
    }
});

// Update a user
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { name, organization, email, password, num_users, mobile, country_name, state_name, expiry_date } = req.body;

    console.log('Updating user with ID:', id); // Debug: Log user ID to be updated
    try {
        const updatedUser = await pool.query(
            `UPDATE register 
             SET name = $1, 
                 organization = $2, 
                 email = $3, 
                 password = $4, 
                 num_users = $5, 
                 mobile = $6, 
                 country_name = $7, 
                 state_name = $8, 
                 expiry_date = $9 
             WHERE id = $10 
             RETURNING *`,
            [name, organization, email, password, num_users, mobile, country_name, state_name, expiry_date, id]
        );
        console.log('Updated user:', updatedUser.rows[0]); // Debug: Log updated user info
        res.json(updatedUser.rows[0]);
    } catch (err) {
        console.error('Error updating user:', err); // Log detailed error
        res.status(500).json({ error: 'Failed to update user' });
    }
});

// Delete a user
router.delete('/:id', async (req, res) => {
    const { id } = req.params;

    console.log('Deleting user with ID:', id); // Debug: Log user ID to be deleted
    try {
        await pool.query('DELETE FROM register WHERE id = $1', [id]);
        console.log('User deleted successfully'); // Debug: Log deletion success
        res.json({ message: 'User deleted successfully' });
    } catch (err) {
        console.error('Error deleting user:', err); // Log detailed error
        res.status(500).json({ error: 'Failed to delete user' });
    }
});

module.exports = router;
