----------------------------DEPENDENCIES------------------------------------
DB CONNECTION DEPENDENCIES

npm install express pg cors body-parser
npm install axios
node server.js

------------------------SERVERS----------------------------------------
laragon postgresql server must be on
express server must be on - run in project directory cmd "node server.js"
---------------------------FILES-------------------------------------
Add "server.js" to your main path ( same as app.js)
Add form.js in your main path ( same as app.js)
update app.js with form imports

-----------------------------CRUD DONE---------------------------------------------
COUNTRY AND STATE CRUD OPERATIONS WORKS FINE

--------------------------------------------------------------------------------------
remove photo and try again
1. try first dropdown selsctabel for both
2. data recored visible in regisetr.js
3. add data
4. photo
5. validate all and copy it and make it sort

