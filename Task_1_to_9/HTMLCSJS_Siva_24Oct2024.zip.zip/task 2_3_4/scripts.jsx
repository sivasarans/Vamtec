
function max_size(input) {
    const max = 2 * 1024 * 1024; // 3 MB in bytes
    const file = input.files[0];

    if (file) {
        // Check file size
        if (file.size > max) {
            alert("Maximum limit is 2MB.");
            console.log("File size exceeds 3MB limit.");
            let x =document.getElementsByClassName(".device-label").value;
            console.log(x)

        }

        // Check file type
        const allowedTypes = ['image/jpeg', 'image/png', 'image/svg+xml'];
        if (!allowedTypes.includes(file.type)) {
            alert("Invalid file type. Only JPG, JPEG, SVG, and PNG are allowed.");
            console.log("Invalid file type:", file.type);

            input.value = ""; // Clear the input if type is invalid
        }
    }
}

function n(input) {
    console.clear();
    const username = document.getElementById("Username").value
    console.log("Username By ID:", username); 
    const querySelector = document.querySelector("#Username").value;
    console.log("Username By querySelector:", querySelector);
}

function mail(input) {
    console.clear();
    const emailByClass = document.getElementsByClassName("m")[0].value;
    console.log("class:", emailByClass);
    const QuerySelector = document.querySelector(".m").value;
    console.log("querySelector:", QuerySelector);
}
function xx() {  
    const x = document.querySelectorAll(".x"); 
    console.clear();

    // Log the values of each input field
    x.forEach((val, i) => {
        console.log(`Enetered Values by QuerySelectorALl ${i + 1}:`, val.value);
    });
}
